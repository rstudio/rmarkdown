# formatR

[![Build Status](https://travis-ci.org/yihui/formatR.svg)](https://travis-ci.org/yihui/formatR)

Format R code automatically.

See the package homepage <http://yihui.name/formatR> for more information.
