data(barley, package = "lattice")
barley
