library(testthat)
library(gtable)

test_package("gtable")