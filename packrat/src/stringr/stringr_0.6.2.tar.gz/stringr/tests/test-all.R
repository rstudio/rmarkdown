library(testthat)
library(stringr)

test_package("stringr")
