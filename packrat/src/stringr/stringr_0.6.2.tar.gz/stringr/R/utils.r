compact <- function(l) Filter(Negate(is.null), l)
