#### -- Packrat Autoloader (version 0.4.2-6) -- ####
source("packrat/init.R")
#### -- End Packrat Autoloader -- ####
